
* For fetching code of Codeforces gym submissions, password is also required. So currently, no gym submissions will be downloaded. 
* Add check to verify if the handle is valid.  
* Add support to download submissions from other sites like HackerRank, HackerEarth etc.